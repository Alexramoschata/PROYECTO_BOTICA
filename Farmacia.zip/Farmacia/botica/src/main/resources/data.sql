-- Datos para la tabla `botica_cargo`
INSERT INTO `botica_cargo` (`id_cargo`, `descripcion`, `nombre_cargo`) VALUES
                                                                           (1, 'Gestión de ventas y atención al cliente', 'Vendedor'),
                                                                           (2, 'Responsable de inventario y suministros', 'Almacenista'),
                                                                           (3, 'Administrador del sistema de botica', 'Administrador'),
                                                                           (4, 'Encargado de atención médica básica', 'Farmacéutico');

-- Datos para la tabla `botica_categoria`
INSERT INTO `botica_categoria` (`id_categoria`, `nombre_categoria`) VALUES
                                                                        (1, 'Medicamentos de venta libre'),
                                                                        (2, 'Medicamentos con receta'),
                                                                        (3, 'Vitaminas y suplementos'),
                                                                        (4, 'Productos de cuidado personal'),
                                                                        (5, 'Equipos médicos');

-- Datos para la tabla `botica_cliente`
INSERT INTO `botica_cliente` (`id_cliente`, `apellido`, `contrasena`, `direccion`, `nombre`, `telefono`, `tipo_cliente`) VALUES
                                                                                                                             (1, 'Perez', 'clave123', 'Av. Los Pinos 123', 'Juan', '987654321', 'Regular'),
                                                                                                                             (2, 'Garcia', 'pass789', 'Calle Las Flores 456', 'Maria', '912345678', 'VIP'),
                                                                                                                             (3, 'Lopez', 'abc12345', 'Jr. Amazonas 789', 'Carlos', '923456789', 'Corporativo'),
                                                                                                                             (4, 'Sanchez', 'xyz0987', 'Av. Grau 101', 'Lucia', '934567890', 'Regular'),
                                                                                                                             (5, 'Ramirez', 'qwerty456', 'Av. Bolognesi 202', 'Luis', '945678901', 'VIP');

-- Datos para la tabla `botica_estado`
INSERT INTO `botica_estado` (`id_estado`, `nombre`) VALUES
                                                        (1, 'Activo'),
                                                        (2, 'Inactivo'),
                                                        (3, 'Pendiente de aprobación'),
                                                        (4, 'Suspendido');

-- Datos para la tabla `botica_producto`
INSERT INTO `botica_producto` (`id_producto`, `categoria`, `descripcion`, `nombre`, `precioventa`, `proveedor`) VALUES
                                                                                                                    (1, 'Medicamentos de venta libre', 'Analgésico de acción rápida', 'Paracetamol', 3.50, 'Laboratorios ACME'),
                                                                                                                    (2, 'Vitaminas y suplementos', 'Suplemento de vitamina C', 'Vitamina C 500mg', 8.90, 'NutriLab'),
                                                                                                                    (3, 'Productos de cuidado personal', 'Jabón antiséptico', 'Jabón Líquido Antibacterial', 5.00, 'CleanCo'),
                                                                                                                    (4, 'Medicamentos con receta', 'Antibiótico para infecciones bacterianas', 'Amoxicilina 500mg', 15.00, 'BioPharma'),
                                                                                                                    (5, 'Equipos médicos', 'Termómetro digital de precisión', 'Termómetro Digital', 25.00, 'HealthTools');
