package com.boticaamanecer.botica.mappers;

import com.boticaamanecer.botica.dtos.CategoriaDTO;
import com.boticaamanecer.botica.modelo.Categoria;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CategoriaMapper extends GenericMapper<CategoriaDTO, Categoria> {
}
