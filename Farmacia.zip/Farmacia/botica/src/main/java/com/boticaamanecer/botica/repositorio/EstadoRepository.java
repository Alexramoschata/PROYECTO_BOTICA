package com.boticaamanecer.botica.repositorio;

import com.boticaamanecer.botica.modelo.Estado;

public interface EstadoRepository extends ICrudGenericoRepository<Estado, Long> {
}
