package com.boticaamanecer.botica.servicio;

import com.boticaamanecer.botica.dtos.ProductoDTO;
import com.boticaamanecer.botica.modelo.Producto;

public interface ProductoService extends ICrudGenericoService<Producto, Long> {
}
