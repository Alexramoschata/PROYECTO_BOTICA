package com.boticaamanecer.botica.servicio.impl;

import com.boticaamanecer.botica.dtos.ClienteDTO;
import com.boticaamanecer.botica.mappers.ClienteMapper;
import com.boticaamanecer.botica.modelo.Categoria;
import com.boticaamanecer.botica.modelo.Cliente;
import com.boticaamanecer.botica.repositorio.CategoriaRepository;
import com.boticaamanecer.botica.repositorio.ClienteRepository;
import com.boticaamanecer.botica.repositorio.ICrudGenericoRepository;
import com.boticaamanecer.botica.servicio.ClienteService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class ClienteServiceImp extends CrudGenericoServiceImp<Cliente, Long> implements ClienteService {
    private final ClienteRepository repo;

    @Override
    protected ICrudGenericoRepository<Cliente, Long> getRepo() { return repo; }

    public Page<Cliente> listaPage(Pageable pageable){
        return repo.findAll(pageable);
    }
}
