package com.boticaamanecer.botica.servicio;

import com.boticaamanecer.botica.dtos.ClienteDTO;
import com.boticaamanecer.botica.modelo.Cliente;

public interface ClienteService extends ICrudGenericoService<Cliente, Long> {

}
