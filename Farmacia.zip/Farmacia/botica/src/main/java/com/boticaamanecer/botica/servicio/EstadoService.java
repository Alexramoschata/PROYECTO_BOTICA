package com.boticaamanecer.botica.servicio;

import com.boticaamanecer.botica.modelo.Estado;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface EstadoService extends ICrudGenericoService<Estado, Long> {
}
