package com.boticaamanecer.botica.servicio.impl;

import com.boticaamanecer.botica.modelo.Estado;
import com.boticaamanecer.botica.repositorio.EstadoRepository;
import com.boticaamanecer.botica.repositorio.ICrudGenericoRepository;
import com.boticaamanecer.botica.servicio.EstadoService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@Transactional
@RequiredArgsConstructor
public class EstadoServiceImp extends CrudGenericoServiceImp<Estado, Long> implements EstadoService {
    private final EstadoRepository estadoRepository;

    @Override
    protected ICrudGenericoRepository<Estado, Long> getRepo() { return estadoRepository; }

    public Page<Estado> listaPage(Pageable pageable){
        return estadoRepository.findAll(pageable);
    }
}
