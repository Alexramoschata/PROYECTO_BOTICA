package com.boticaamanecer.botica.servicio;

import com.boticaamanecer.botica.modelo.Cargo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface CargoService extends ICrudGenericoService<Cargo, Long> {
}
