import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {MaterialModule} from "../../../material/material.module";
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgIf} from "@angular/common";
import {Estado} from "../../../modelo/Estado";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {EstadoService} from "../../../servicio/estado.service";
import {switchMap} from "rxjs";

@Component({
  selector: 'app-form-estado',
  standalone: true,
  imports: [MaterialModule, FormsModule, NgIf, ReactiveFormsModule],
  templateUrl: './form-estado.component.html',
  styleUrl: './form-estado.component.css'
})
export class FormEstadoComponent implements OnInit {

  @ViewChild('EstadoForm') estadoForm!: NgForm ;
  form: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Estado,
    private krService: EstadoService,
    private _dialogRef: MatDialogRef<FormEstadoComponent>

  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['nombre']);

      this.form = new FormGroup({
        idEstado: new FormControl(this.data['idEstado']),
        nombre: new FormControl(this.data['nombre'], [Validators.required, Validators.minLength(3), Validators.maxLength(100)])
      });


    }else{
      this.form = new FormGroup({
        idEstado: new FormControl(0),
        nombre: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(100)])
      });
    }
  }

  close(){
    this._dialogRef.close();
  }

  operate(){
    const estado: Estado = new Estado();
    estado.idEstado = this.form.value['idEstado'];
    estado.nombre = this.form.value['nombre'];

    if(this.estadoForm.valid){
      if(estado.idEstado > 0){
        //UPDATE
        this.krService.update(estado.idEstado, estado)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setEstadoChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });

      }else{
        //INSERT
        this.krService.save(estado)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setEstadoChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }

  }

  get f(){
    return this.form.controls;
  }

}
