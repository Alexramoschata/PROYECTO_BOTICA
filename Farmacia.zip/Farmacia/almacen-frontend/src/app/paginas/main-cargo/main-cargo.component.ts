import {Component, OnInit, ViewChild} from '@angular/core';
import {Cargo} from "../../modelo/Cargo";
import {CargoService} from "../../servicio/cargo.service";
import {FormCargoComponent} from "./form-cargo/form-cargo.component";
import {MatTableDataSource} from "@angular/material/table";
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {MatDialog} from "@angular/material/dialog";
import {MatSnackBar} from "@angular/material/snack-bar";
import {switchMap} from "rxjs";
import {MaterialModule} from "../../material/material.module";
import {RouterLink, RouterOutlet} from "@angular/router";

@Component({
  selector: 'app-main-cargo',
  standalone: true,
  imports: [MaterialModule, RouterOutlet, RouterLink],
  templateUrl: './main-cargo.component.html',
  styleUrl: './main-cargo.component.css'
})
export class MainCargoComponent implements OnInit{
  dataSource: MatTableDataSource<Cargo>;

  columnsDefinitions = [
    { def: 'idCargo', label: 'idCargo', hide: true},
    { def: 'nombreCargo', label: 'nombreCargo', hide: false},
    { def: 'descripcion', label: 'descripcion', hide: false},
    { def: 'acciones', label: 'acciones', hide: false}
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(
      private krervice: CargoService,
      private _dialog: MatDialog,
      private _snackBar: MatSnackBar
  ){}

  ngOnInit(): void {
    this.krervice.findAll().subscribe(data => this.createTable(data));

    this.krervice.getCargoChange().subscribe(data => this.createTable(data));
    this.krervice.getMessageChange().subscribe(data => this._snackBar.open(data, 'INFO', {duration: 2000}))
  }

  createTable(data: Cargo[]){
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  getDisplayedColumns(){
    return this.columnsDefinitions.filter(cd => !cd.hide).map(cd => cd.def);
  }

  openDialog(cargo?: Cargo){
    this._dialog.open(FormCargoComponent, {
      width: '750px',
      data: cargo,
      disableClose: true
    });
  }


  delete(idMedic: number){
    this.krervice.delete(idMedic)
        .pipe(switchMap( ()=> this.krervice.findAll()))
        .subscribe(data => {
          this.krervice.setCargoChange(data);
          this.krervice.setMessageChange('DELETED!');
        });
  }
}
