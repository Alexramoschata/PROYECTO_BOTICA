import {Component, Inject, ViewChild} from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {MaterialModule} from "../../../material/material.module";
import {NgIf} from "@angular/common";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {Cargo} from "../../../modelo/Cargo";
import {CargoService} from "../../../servicio/cargo.service";
import {switchMap} from "rxjs";

@Component({
  selector: 'app-form-cargo',
  standalone: true,
  imports: [MaterialModule, FormsModule, NgIf, ReactiveFormsModule],
  templateUrl: './form-cargo.component.html',
  styleUrl: './form-cargo.component.css'
})
export class FormCargoComponent {
  @ViewChild('CargoForm') cargoForm!: NgForm ;
  form: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Cargo,
    private krService: CargoService,
    private _dialogRef: MatDialogRef<FormCargoComponent>

  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['nombreCargo']);

      this.form = new FormGroup({
        idCargo: new FormControl(this.data['idCargo']),
        nombreCargo: new FormControl(this.data['nombreCargo'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        descripcion: new FormControl(this.data['descripcion'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });


    }else{
      this.form = new FormGroup({
        idCargo: new FormControl(0),
        nombreCargo: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        descripcion: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }
  }

  close(){
    this._dialogRef.close();
  }

  operate(){
    const cargo: Cargo = new Cargo();
    cargo.idCargo = this.form.value['idCargo'];
    cargo.nombreCargo = this.form.value['nombreCargo'];
    cargo.descripcion = this.form.value['descripcion'];

    if(this.cargoForm.valid){
      if(cargo.idCargo > 0){
        //UPDATE
        this.krService.update(cargo.idCargo, cargo)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setCargoChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });

      }else{
        //INSERT
        this.krService.save(cargo)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setCargoChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }

  }

  get f(){
    return this.form.controls;
  }

}
