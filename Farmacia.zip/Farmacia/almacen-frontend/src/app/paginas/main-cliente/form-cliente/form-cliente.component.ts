import {Component, Inject, OnInit, ViewChild} from '@angular/core';
import {FormControl, FormGroup, FormsModule, NgForm, ReactiveFormsModule, Validators} from "@angular/forms";
import {NgIf} from "@angular/common";
import {MaterialModule} from "../../../material/material.module";
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import {Cliente} from "../../../modelo/Cliente";
import {ClienteService} from "../../../servicio/cliente.service";
import {switchMap} from "rxjs";

@Component({
  selector: 'app-form-cliente',
  standalone: true,
  imports: [MaterialModule, FormsModule, NgIf, ReactiveFormsModule],
  templateUrl: './form-cliente.component.html',
  styleUrl: './form-cliente.component.css'
})
export class FormClienteComponent implements OnInit {
  @ViewChild('ClienteForm') clienteForm!: NgForm ;
  form: FormGroup;

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: Cliente,
    private krService: ClienteService,
    private _dialogRef: MatDialogRef<FormClienteComponent>

  ){}
  ngOnInit(): void {
    if(this.data!==undefined){
      console.log(this.data['nombre']);
      console.log(this.data['apellido']);
      console.log(this.data['telefono']);
      console.log(this.data['direccion']);
      console.log(this.data['contrasena']);
      console.log(this.data['tipoCliente']);

      this.form = new FormGroup({
        idCliente: new FormControl(this.data['idCliente']),
        nombre: new FormControl(this.data['nombre'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        apellido: new FormControl(this.data['apellido'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        telefono: new FormControl(this.data['telefono'], [Validators.required, Validators.minLength(9), Validators.maxLength(9)]),
        direccion: new FormControl(this.data['direccion'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        contrasena: new FormControl(this.data['contrasena'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        tipoCliente: new FormControl(this.data['tipoCliente'], [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });


    }else{
      this.form = new FormGroup({
        idCliente: new FormControl(0),
        nombre: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        apellido: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        telefono: new FormControl('', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]),
        direccion: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        contrasena: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]),
        tipoCliente: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)])
      });
    }
  }

  close(){
    this._dialogRef.close();
  }

  operate(){
    const cliente: Cliente = new Cliente();
    cliente.idCliente = this.form.value['idCliente'];
    cliente.nombre = this.form.value['nombre'];
    cliente.apellido = this.form.value['apellido'];
    cliente.telefono = this.form.value['telefono'];
    cliente.direccion = this.form.value['direccion'];
    cliente.contrasena = this.form.value['contrasena'];
    cliente.tipoCliente = this.form.value['tipoCliente'];

    if(this.clienteForm.valid){
      if(cliente.idCliente > 0){
        //UPDATE
        this.krService.update(cliente.idCliente, cliente)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setClienteChange(data);
            this.krService.setMessageChange('UPDATED!');
            this.close();
          });

      }else{
        //INSERT
        this.krService.save(cliente)
          .pipe(switchMap( ()=> this.krService.findAll() ))
          .subscribe(data => {
            this.krService.setClienteChange(data);
            this.krService.setMessageChange('CREATED!');
            this.close();
          });
      }
    }else{
      console.log("Error....")
    }

  }

  get f(){
    return this.form.controls;
  }

}
