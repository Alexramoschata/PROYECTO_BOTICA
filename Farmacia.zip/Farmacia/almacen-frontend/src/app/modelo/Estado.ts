export class Estado {
  idEstado: number
  nombre: string
}
