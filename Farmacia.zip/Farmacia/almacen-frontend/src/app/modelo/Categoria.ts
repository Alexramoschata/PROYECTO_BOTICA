export class Categoria {
  idCategoria: number
  nombreCategoria: string
}
